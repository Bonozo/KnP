<?php
/**
 * @package		JomSocial
 * @subpackage 	Template 
 * @copyright (C) 2008 by Slashes & Dots Sdn Bhd - All rights reserved!
 * @license		GNU/GPL, see LICENSE.php
 * 
 */
defined('_JEXEC') or die( 'Restricted Access' );
?>
<div style="border:1px solid #FF0000; padding:20px; background-color:#FFEAEA">
<?php echo JText::_('COM_COMMUNITY_NOT_ALLOWED_TO_VIEW_PAGE');?>
</div>