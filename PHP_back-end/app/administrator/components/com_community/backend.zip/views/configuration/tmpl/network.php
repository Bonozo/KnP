<?php
/**
 * @category	Core
 * @package		JomSocial
 * @copyright (C) 2008 by Slashes & Dots Sdn Bhd - All rights reserved!
 * @license		GNU/GPL, see LICENSE.php
 */
// Disallow direct access to this file
defined('_JEXEC') or die('Restricted access');
?>
<table  width="100%">
	<tr>
		<td width="50%">
			<?php require_once( dirname(__FILE__) . DS . 'network_form.php' ); ?>
		</td>
		<td  width="50%">
			<?php require_once( dirname(__FILE__) . DS . 'network_info.php' ); ?>
		</td>
	</tr>
</table>
